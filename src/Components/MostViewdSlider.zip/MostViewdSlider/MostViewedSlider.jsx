import React from 'react';
import { BiLeftArrow, BiRightArrow } from "react-icons/bi";

const MostViewedSlider = () => {
    const items = [
        {
            title: "Printed Chiffon",
            viewed: "532 viewed",
            img: "https://images.othoba.com/images/thumbs/0350769_proton-m-earphone-neck-band-p5-blue.jpeg"
        },
        {
            title: "Printed Chiffon",
            viewed: "532 viewed",
            img: "https://images.othoba.com/images/thumbs/0350769_proton-m-earphone-neck-band-p5-blue.jpeg"
        },
        {
            title: "Printed Chiffon",
            viewed: "532 viewed",
            img: "https://images.othoba.com/images/thumbs/0350769_proton-m-earphone-neck-band-p5-blue.jpeg"
        },
        {
            title: "Printed Chiffon",
            viewed: "532 viewed",
            img: "https://images.othoba.com/images/thumbs/0350769_proton-m-earphone-neck-band-p5-blue.jpeg"
        },
        {
            title: "Printed Chiffon",
            viewed: "532 viewed",
            img: "https://images.othoba.com/images/thumbs/0350769_proton-m-earphone-neck-band-p5-blue.jpeg"
        },
        {
            title: "Printed Chiffon",
            viewed: "532 viewed",
            img: "https://images.othoba.com/images/thumbs/0350769_proton-m-earphone-neck-band-p5-blue.jpeg"
        },
        {
            title: "Printed Chiffon",
            viewed: "532 viewed",
            img: "https://images.othoba.com/images/thumbs/0350769_proton-m-earphone-neck-band-p5-blue.jpeg"
        },
        {
            title: "Printed Chiffon",
            viewed: "532 viewed",
            img: "https://images.othoba.com/images/thumbs/0350769_proton-m-earphone-neck-band-p5-blue.jpeg"
        },
    ]
    return (
        <div className='container mx-auto flex m-20'>
            <div className='slide-images-navigation'>
                <h3>Most Viewd</h3>
                <div className='flex'>
                    <button className=''><BiLeftArrow /></button>
                    <button><BiRightArrow /></button>
                </div>
            </div>
            <div className='slide-images-card'>
                <div>
                    <div className='flex flex-nowrap'>
                        {
                            items.map((item, index) =>
                                <div key={index} className="card w-52 bg-base-100 shadow-xl">

                                    <div className="card-body items-center text-center">
                                        <h2 className="card-title">{item.title}</h2>
                                        <p>{item.viewed}</p>
                                    </div>
                                    <figure className="px-10 pt-10">
                                        <img src={item.img} alt="Shoes" className="rounded-xl" />
                                    </figure>
                                </div>)
                        }
                    </div>
                </div>
            </div>
        </div>
    );
};

export default MostViewedSlider;